<?php
	$server='localhost';
	$user='root';
	$pwd='';
	$error='�������ݿ����';
	$conn=mysql_connect($server,$user,$pwd);
	if (!$conn) {
		die ($error);
	}
	mysql_query("set names 'GBK'");
    mysql_select_db('myguest',$conn);
    

	//�ı�������
	function encode($varchar) {
		$varchar=trim($varchar);   //���ַ���ȡ�հ�
		$varchar=addslashes($varchar);  //�������ţ�˫���ţ�б�ܼ�б��
		$varchar=htmlspecialchars($varchar);  //<>��ת���������ַ�����
		$varchar=nl2br($varchar);   //��\nת����<br />
		//$varchar=strtolower($varchar);ת����Сд
		$encode=StaticSystem('encode');
		$mode=array("/$encode/");
		$neeld=array('*.*');
		$varchar=preg_replace($mode,$neeld,$varchar);
		return $varchar;
	}
	
	//ubb����
	function ubb($str) {
		//ͼƬ�滻
		$str=preg_replace('/(\[img\])(.*)(\[\/img\])/iU','<img src="\\2" />',$str);
		//������ɫ�滻
		$str=preg_replace('/(\[color=(.*)\])(.*)(\[\/color\])/iU','<span style="color:\\2">\\3</span>',$str);
		//�����滻
		$str=preg_replace('/(\[url=(.*)\])(.*)(\[\/url\])/iU','<a href="\\2" target="_blank">\\3</a>',$str);
		return $str;
	}
	
	//��վ��������
	if (!StaticSystem('state')) {
		echo StaticSystem('close');
		exit;
	}
	
	//ϵͳ����
	function StaticSystem($str) {
		$sqlSystem="select * from g_system where G_ID=1";
		$querySystem=mysql_query($sqlSystem);
		$rowSystem=mysql_fetch_array($querySystem);
		if ($rowSystem) {
			switch ($str) {
				case 'webname':
					$str=$rowSystem['G_Webname'];
					break;
				case 'article':
					if ($rowSystem['G_Aritcle']==1) {
						$str=10;
					}
					else if ($rowSystem['G_Aritcle']==2) {
						$str=15;
					}
					break;
				case 'blog':
					if ($rowSystem['G_Blog']==1) {
						$str=15;
					}
					else if ($rowSystem['G_Blog']==2) {
						$str=20;
					}
					break;
				case 'photo':
					if ($rowSystem['G_Photo']==1) {
						$str=8;
					}
					else if ($rowSystem['G_Photo']==2) {
						$str=12;
					}
					break;
				case 'skin':
					if ($rowSystem['G_Skin']==1) {
						$str=1;
					}
					else if ($rowSystem['G_Skin']==2) {
						$str=2;
					}
					else if ($rowSystem['G_Skin']==3) {
						$str=3;
					}	
					if ($_COOKIE['skin']) {
						$str=$_COOKIE['skin'];
					}
					break;
				case 'systemskin':
					if ($rowSystem['G_Skin']==1) {
						$str=1;
					}
					else if ($rowSystem['G_Skin']==2) {
						$str=2;
					}
					else if ($rowSystem['G_Skin']==3) {
						$str=3;
					}
					break;	
				case 'state':
					if ($rowSystem['G_State']==0) {
						$str=0;
					}
					else if ($rowSystem['G_State']==1) {
						$str=1;
					}
					break;	
				case 'close':
					$str=$rowSystem['G_Close'];
					break;
				case 'encode':
					$str=$rowSystem['G_Encode'];
					break;
				case 'time':
					if ($rowSystem['G_Time']==30) {
						$str=30;
					}
					else if ($rowSystem['G_Time']==60) {
						$str=60;
					}
					else if ($rowSystem['G_Time']==180) {
						$str=160;
					}
					break;	
				case 'yzm':
					if ($rowSystem['G_Yzm']==0) {
						$str=0;
					}
					else if($rowSystem['G_Yzm']==1) {
						$str=1;
					} 
					break;
				case 'reg':
					if ($rowSystem['G_Reg']==0) {
						$str=0;
					}
					else if ($rowSystem['G_Reg']==1) {
						$str=1;
					}
					break;
				case 'vis':
					if ($rowSystem['G_Vis']==0) {
						$str=0;
					}
					else if ($rowSystem['G_Vis']==1) {
						$str=1;
					}
					break;
				default:
					break;
			}
		}
		return $str;
	}
?>