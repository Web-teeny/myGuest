<?php 
ob_start();
setcookie("user", "Alex Porter",time()+3600);
?>
<html>
<body>
<?php
if (isset($_COOKIE["user"]))
{
echo "Welcome " . $_COOKIE["user"] . "!<br />";
}
else
  echo "Welcome guest!<br />";
?>
<input type="button" onclick="javascript:location.href='out.php'" value="����"></input>
</body>
</html>