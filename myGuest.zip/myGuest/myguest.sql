-- phpMyAdmin SQL Dump
-- version 2.11.9.2
-- http://www.phpmyadmin.net
--
-- 主机: 127.0.0.1:3306
-- 生成日期: 2016 年 07 月 31 日 12:16
-- 服务器版本: 5.1.28
-- PHP 版本: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `myguest`
--
CREATE DATABASE `myguest` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `myguest`;

-- --------------------------------------------------------

--
-- 表的结构 `g_article`
--

CREATE TABLE IF NOT EXISTS `g_article` (
  `G_ID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `G_Title` varchar(50) CHARACTER SET gbk NOT NULL,
  `G_UserName` varchar(20) CHARACTER SET gbk NOT NULL,
  `G_Sex` char(1) CHARACTER SET gbk NOT NULL,
  `G_Face` varchar(20) CHARACTER SET geostd8 NOT NULL,
  `G_Email` varchar(40) CHARACTER SET gbk NOT NULL,
  `G_QQ` varchar(20) CHARACTER SET gbk NOT NULL,
  `G_Url` varchar(40) CHARACTER SET gbk NOT NULL,
  `G_Brow` varchar(20) CHARACTER SET gbk NOT NULL,
  `G_Content` text CHARACTER SET gbk NOT NULL,
  `G_ReId` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `G_ReadCount` smallint(6) NOT NULL DEFAULT '0',
  `G_CommentCount` smallint(6) NOT NULL DEFAULT '0',
  `G_Date` datetime NOT NULL,
  PRIMARY KEY (`G_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- 导出表中的数据 `g_article`
--


-- --------------------------------------------------------

--
-- 表的结构 `g_message`
--

CREATE TABLE IF NOT EXISTS `g_message` (
  `G_ID` mediumint(8) unsigned NOT NULL,
  `G_ToUser` varchar(20) CHARACTER SET gbk NOT NULL,
  `G_FromUser` varchar(20) CHARACTER SET gbk NOT NULL,
  `G_Content` varchar(200) CHARACTER SET gbk NOT NULL,
  `G_Date` datetime NOT NULL,
  PRIMARY KEY (`G_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- 导出表中的数据 `g_message`
--


-- --------------------------------------------------------

--
-- 表的结构 `g_system`
--

CREATE TABLE IF NOT EXISTS `g_system` (
  `G_ID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '系统设置ID',
  `G_Webname` varchar(50) CHARACTER SET gbk NOT NULL COMMENT '网站名称',
  `G_Aritcle` tinyint(1) unsigned NOT NULL COMMENT '文章每页条数',
  `G_Blog` tinyint(1) unsigned NOT NULL COMMENT '博客每页条数',
  `G_Photo` tinyint(1) unsigned NOT NULL COMMENT '相册每页条数',
  `G_Skin` tinyint(1) unsigned NOT NULL COMMENT '网站默认风格设置',
  `G_State` tinyint(1) unsigned NOT NULL COMMENT '网站状态',
  `G_Close` varchar(200) CHARACTER SET gbk NOT NULL COMMENT '网站关闭原因',
  `G_Encode` varchar(200) CHARACTER SET gbk NOT NULL COMMENT '非法字符过滤',
  `G_Time` tinyint(3) unsigned NOT NULL COMMENT '发帖间隔',
  `G_Yzm` tinyint(1) unsigned NOT NULL COMMENT '是否启用验证码',
  `G_Reg` tinyint(1) unsigned NOT NULL COMMENT '是否开启注册',
  `G_Vis` tinyint(1) unsigned NOT NULL COMMENT '游客是否能发帖',
  PRIMARY KEY (`G_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- 导出表中的数据 `g_system`
--

INSERT INTO `g_system` (`G_ID`, `G_Webname`, `G_Aritcle`, `G_Blog`, `G_Photo`, `G_Skin`, `G_State`, `G_Close`, `G_Encode`, `G_Time`, `G_Yzm`, `G_Reg`, `G_Vis`) VALUES
(1, '初体验留言板项目', 1, 2, 2, 1, 1, '系统正在维护，请稍后再访问！开启请修改MYSQL相关字段参数值，暂不支持页面设置开启', '他妈的|NND|草|操|垃圾|淫荡|贱货|SB|sb|jb|JB|法轮功|小泉', 60, 1, 1, 1);

-- --------------------------------------------------------

--
-- 表的结构 `g_users`
--

CREATE TABLE IF NOT EXISTS `g_users` (
  `G_ID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `G_UserName` char(15) CHARACTER SET gbk NOT NULL,
  `G_PassWord` char(32) CHARACTER SET big5 NOT NULL,
  `G_PassT` varchar(20) CHARACTER SET gbk DEFAULT NULL,
  `G_PassD` char(32) CHARACTER SET gbk DEFAULT NULL,
  `G_Sex` char(2) CHARACTER SET gbk NOT NULL,
  `G_Face` varchar(100) CHARACTER SET gbk NOT NULL,
  `G_Email` varchar(100) CHARACTER SET gbk DEFAULT NULL,
  `G_QQ` varchar(12) CHARACTER SET gbk DEFAULT NULL,
  `G_Url` varchar(100) CHARACTER SET gbk DEFAULT NULL,
  `G_Flower` mediumint(8) NOT NULL,
  `G_Degree` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `G_Date` datetime NOT NULL,
  PRIMARY KEY (`G_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- 导出表中的数据 `g_users`
--

INSERT INTO `g_users` (`G_ID`, `G_UserName`, `G_PassWord`, `G_PassT`, `G_PassD`, `G_Sex`, `G_Face`, `G_Email`, `G_QQ`, `G_Url`, `G_Flower`, `G_Degree`, `G_Date`) VALUES
(4, '114', '96e79218965eb72c92a549dd5a330112', 'hh', 'a3aca2964e72000eea4c56cb341002a4', '男', 'face/m43.gif', '', '', 'http://', 0, 0, '2016-07-30 23:01:08'),
(3, '111', '96e79218965eb72c92a549dd5a330112', '', 'd41d8cd98f00b204e9800998ecf8427e', '男', 'face/m10.gif', '', '', 'http://', 0, 0, '2016-07-30 21:48:39'),
(5, '110', '96e79218965eb72c92a549dd5a330112', '', 'd41d8cd98f00b204e9800998ecf8427e', '女', 'face/m44.gif', '', '', 'http://', 0, 0, '2016-07-31 11:32:19'),
(6, '123', '96e79218965eb72c92a549dd5a330112', '', 'd41d8cd98f00b204e9800998ecf8427e', '男', 'face/m17.gif', '123@qq.com', '', 'http://myindex.cn', 0, 0, '2016-07-31 14:34:07'),
(7, '112', '96e79218965eb72c92a549dd5a330112', '', 'd41d8cd98f00b204e9800998ecf8427e', '女', 'face/m31.gif', '004@sina.com', '', 'http://114.com', 0, 0, '2016-07-31 20:06:08');
