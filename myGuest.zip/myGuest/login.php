<?php 
session_start();
include 'conn.php';
?>
 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gbk" />
<title>���԰�</title>
<link rel="stylesheet" type="text/css" href="css/1.css"/>
<link rel="shortcut icon" href="favicon.ico"/>
<script type="text/javascript" src="js/login.js"></script>
</head>
<body>
<?php 
include 'header.php';
?>
<div id="main">
  <div id="login">
    <h1>�û���½ </h1>
    <form  action="login_do.php" method="post" name="register">
    <dl id="login_input">
    <dd>�� �� ����<input name="username" type="text" class="text"/></dd>
    <dd>�ܡ����룺<input name="password" type="password" class="text"/></dd>
    <?php 
    if(StaticSystem('yzm')){
    ?>
    <dd>�� ֤ �룺<input name="yzm" type="text" class="yzm" /><img src="code.php" style="position:relative;left:10px;top:10px;cursor:pointer" onclick="javascript:this.src='code.php?tm='+Math.random()" /></dd>
    <?php 
    } else{
    	echo "<input type=\"hidden\" name=\"yzm\" value=\"1234\">";
    }
    ?>
    <dd style="padding-top:8px;">��½������<input name="login" type="radio" value="1" checked="checked"/>������&nbsp;<input name="login" type="radio" value="3600" />1Сʱ&nbsp;<input name="login" type="radio" value="86400" />1��&nbsp;<input name="login" type="radio" value="604800" />1��</dd>
    <dd style="padding-left:240px;"><input name="send" type="submit" class="button" value="��½" onclick="return check();"/><input type="button" class="button" value="ע��" onclick="javascript:location.href='reg.php';" /></dd>
    </dl>
    </form>
  </div>
</div>
<?php
include 'validate.php';
include 'footer.php';
mysql_close();
?>
</body>
</html>