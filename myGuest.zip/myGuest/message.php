<?php 
	if(!$_COOKIE['UserName']){
		echo "<script>alert(\"���ȵ�¼��\");history.back();</script>";
		exit;
	}
	
	$ToUser = $_GET['ToUser'];
	if($ToUser == $_COOKIE['UserName']){
		echo "<script>alert(\"���ܸ��Լ�����Ϣ��\");window.close();</script>";
		exit;
	}
	include 'conn.php';
	if($_POST['send']){
		date_default_timezone_set('Asia/ShangHai');
		$ToUser = $_POST['ToUser'];
		$Content = $_POST['content'];
		$FromUser = $_COOKIE['UserName'];
		$Date = date('Y-m-d H:m:s');
		if(strlen($Content) > 200){
			echo "<script>alert(\"��Ϣ��������200��\");window.close();</script>";
			exit;
		}
		$sql = "insert into g_message(G_ToUser,G_FromUser,G_Content,G_Date) values ('$ToUser','$FromUser','$Content','$Date')";
		mysql_query($sql);
		if(mysql_affected_rows() == 1){
			echo "<script>alert(\"��Ϣ���ͳɹ���\");window.close();</script>";
		} else{
			echo "<script>alert(\"����ʧ�ܣ�\");window.close();</script>";
		}  
	}
	
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>�����ѷ���Ϣ</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<link rel="shortcut icon" href="favicon.ico" />
<link rel="stylesheet" type="text/css" href="css/1.css" />
</head>
<body>
<form action="message.php" method="post" name="message">
<div id="m_title">�����ѷ�����</div>
<div id="m_ToUser">To: �û���<input name="ToUser" type="text" readonly="readonly" value="<?=$ToUser ?>"></input></div>
<div id="m_Content"><textarea name="content"></textarea></div>
<div id= "m_send"><input type="submit" name="send" value="����"></input><input style="margin-left:15px;" type="button" value="ȡ��" onclick="javascript:window.close();"></input></div>
</form>
</body>
</html>
<?php 
     mysql_close();
?>