<?php 
session_start();
include 'conn.php';
?>
 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gbk" />
<title>���԰�</title>
<link rel="stylesheet" type="text/css" href="css/1.css"/>
<link rel="shortcut icon" href="favicon.ico"/>
</head>
<body>
<?php 
include 'header.php';
$xml = new DOMDocument();
	$xml->load('new.xml');
	foreach ($xml -> getElementsByTagName('face') as $list){
		$value = $list -> firstChild -> nodeValue;
		$xmlFace = $value;
	}
	foreach ($xml -> getElementsByTagName('sex') as $list){
		$value = $list -> firstChild -> nodeValue;
		$xmlSex = iconv('utf-8','gbk',$value);
	}
	foreach ($xml -> getElementsByTagName('username') as $list){
		$value = $list -> firstChild -> nodeValue;
		$xmlUsername = iconv('utf-8','gbk',$value);
	}
	foreach ($xml -> getElementsByTagName('email') as $list){
		$value = $list -> firstChild -> nodeValue;
		$xmlEmail = iconv('utf-8','gbk',$value);
	}
	foreach ($xml -> getElementsByTagName('url') as $list){
		$value = $list -> firstChild -> nodeValue;
		$xmlUrl = iconv('utf-8','gbk',$value);
	}
	$sql = "select * from g_article where G_ReId=0";
	$query = mysql_query($sql);
	$num = mysql_num_rows($query);
	$pagesize=StaticSystem('article');
	$pageasolute = ceil($num/$pagesize);
	$page = $_GET['page'];
	if(!is_numeric($page)){
		$page = 1;
	}
	$pageurl = $page;
	if($pageurl <= 0){
		$pageurl = 1;
	}
	if($pageurl >$pageasolute){
		$pageurl = $pageasolute;
	}
	$pagenum = ($pageurl-1)*$pagesize;
	if($pageurl == 1){
		$first = "��ҳ";
		$prev = "��һҳ";
	} else{
		$pageurlfirst = $pageurl-1;
		$first = "<a href='index.php'>��ҳ</a>";
		$prev = "<a href='index.php?page=$pageurlfirst'>��һҳ</a>";
	}
	if($pageurl == $pageasolute){
		$last = "βҳ";
		$next = "��һҳ";
	} else{
		$pageurlnext = $pageurl+1;
		$last = "<a href='index.php?page=$pageasolute'>βҳ</a>";
		$next = "<a href='index.php?page=$pageurlnext'>��һҳ</a>";
	}
	$sql = "select * from g_article where `G_ReId`=0 order by G_Date desc limit $pagenum,$pagesize";
	$query = mysql_query($sql);
?>
<div id="main">
  <div id="list">
    <h1>��������  </h1>
    <div  id="article_1">
      <div id="write"><a href="post.php"></a></div>
      <div id="a_list">
        <ul>
        <?php 
				while (($row=mysql_fetch_array($query))) {
					//���һ�����µ�ͼ��
					$icon='images/1/icon'.mt_rand(1,6).'.gif';
				?>
          <li><img src="<?=$icon ?>"/><a href="#"><?=$row['G_Title'] ?></a><em>�Ķ���(<strong><?=$row['G_ReadCount'] ?></strong>) ������(<strong><?=$row['G_CommentCount'] ?></strong>)</em></li>
          <?php } ?>
        </ul>
      </div>
      <div id="page"><?=$pageurl ?>/<?=$pageasolute?>ҳ | ��<strong><?=$num ?></strong>ƪ���� | <?=$first ?> | <?=$prev ?> | <?=$next ?> | <?=$last ?></div>
      
    </div> 
  </div>
 <div id="newvip">
		<h1>�½���Ա��<?=$xmlUsername ?> (<?=$xmlSex ?>)</h1>
		<dl>
			<dt><img src="<?=$xmlFace ?>" /></dt>
			<dd><span class="x1"><a href="###" class="newa" onclick="javascript:window.open('message.php?ToUser=<?=$xmlUsername ?>','Message','width=400,height=220')">����Ϣ</a></span><span class="x2"><a class="newa" href="friend.php?ToUser=<?=$xmlUsername ?>">��Ϊ����</a></span></dd>
			<dd><span class="x3">д����</span><span class="x4"><a href="flower.php?ToUser=<?=$xmlUsername ?>" class="newa">�����ͻ�</a></span></dd>
			<dd></dd>	
			<dd class="x">�ʼ���<a href="mailto:<?=$xmlEmail ?>"><?=$xmlEmail ?></a></dd>
			<dd class="x">��ҳ��<a href="<?=$xmlUrl ?>" target="_blank"><?=$xmlUrl ?></a></dd>
		</dl>
	</div>
  <div id="photo">
    <h1>���ͼƬ��ħ��������������</h1>
    <dl>
    <dt><img src="photo/20090426125343/20090426221151.jpg"/></dt>
    </dl>
  </div> 
</div>
<?php 
include 'footer.php';
?>
</body>
</html>
 