<?php
/** 
 * TestGuest Version1.0
 * ================================================ 
 * Copy 2015-2016 Annabelle 
 * Web: http://www.gwphp2011.com 
 * ================================================ 
 * Author: Annabelle 
 * Date: 2016-7-27 
 */
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gbk" />
<title>���԰�ͷ��ѡ��</title>
<link rel="stylesheet" type="text/css" href="css/1.css"/>
<script type="text/javascript">
	function chg(url) {
		window.opener.document.register.face.value=url;
		window.opener.document.register.faceImg.src=url;	
	}
</script>
</head>
<body>
<h1 id="face_title">ѡ��ͷ�� </h1>
<dl class="face_dl">
<?php 
for($i = 1;$i < 9; $i++){
	echo '<dd><img src="face/m0'.$i.'.gif" onclick="chg(\'face/m0'.$i.'.gif\')"></dd>';
	
}
?>
</dl>
<dl class="face_dl">
	<?php
		for ($i=10;$i<=64;$i++) {
			echo '<dd><img src="face/m'.$i.'.gif" onclick="chg(\'face/m'.$i.'.gif\')"></dd>';
		}
		mysql_close();
	?>
</dl>
</body>
</html>
