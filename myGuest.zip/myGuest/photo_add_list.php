<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>���԰�</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<link rel="shortcut icon" href="favicon.ico" />
<link rel="stylesheet" type="text/css" href="css/1.css" />
</head>
<body>
<div id="main">
<div id="photos">
<div id="photo_head">��������б�</div>
<div id="photo_upload">
<dl>
<dd>�������<input type="text" name="PhotoName"></input></dd>
<dd><input type="radio" value="0" checked="checked" name="listype">����</input><input type="radio" value="1" name="listype">˽��</input></dd>
<dd>�����<textarea></textarea></dd>
<dd style="margin-left:80px;"><input class="submit" type="button" value="����ͼƬ" ></input></dd>
</dl>
</div>

</div>
</div>
</body>
</html>