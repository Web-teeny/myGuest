<?php
     include 'conn.php';
     $ToUser = $_GET['ToUser'];
     if(!$ToUser){
     	echo "<script>alert(\"�Ƿ���½��\");history.back();</script>";
     	exit;
     }
     if(!$_COOKIE['UserName']){
     	echo "<script>alert(\"�οͲ����ͻ���\");history.back();</script>";
     	exit;
     }
     if($ToUser == $_COOKIE['UserName']){
     	echo "<script>alert(\"�㲻�ܸ��Լ��ͻ���\");history.back();</script>";
     	exit;
     }
     if($ToUser && ($_COOKIE['UserName'])){
     	$ToUser = $_GET['ToUser'];
     	$FromUser = $_COOKIE['UserName'];
     	date_default_timezone_set('Asia/ShangHai');
     	$Date = date('Y-m-d H:m:s');
     	$sql = "insert into g_flower(G_ToUser,G_FromUser,G_Date) values ('$ToUser','$FromUser','$Date')";
     	mysql_query($sql);
     	$sql = "update g_users set G_Flower=G_Flower+1 where G_UserName='$ToUser'";
     	mysql_query($sql);
     	mysql_close();
     	echo "<script>alert('����{$ToUser}����һ֦����');history.back();</script>";
     }
 ?>