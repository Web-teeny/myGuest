<script type="text/javascript">
function ListOver(x){
	document.getElementById(x).style.display="block";
	}
	
function ListOut(x){
	document.getElementById(x).style.display="none";
	}
</script>
<div class="header">
  <ul>
  <li><a href="index.php">��ҳ</a></li>  
  <?php 
  if($_COOKIE['UserName']){
  	echo "<li><a href='member.php'>".$_COOKIE['UserName']."����</a></li>";
  }else{
  	echo "<li><a href='reg.php'>ע��</a></li>";
  	echo "<li><a href='login.php'>��½</a></li>";
  }
  ?>
    <li><a href="#">���</a></li>
    <li><a href="#">����</a></li>
    <li class="skin" onmouseover="ListOver('skin')" onmouseout="ListOut('skin')">���
    <dl id="skin" >
    <dd><a href="#">1.��ɫɭ��</a></dd>
    <dd><a href="#">2.����ջ�</a></dd>
    <dd><a href="#">3.��������</a></dd>
    </dl>
    <?php 
    if($_COOKIE['UserName']){
    	if($_SESSION['Admin']){
    		echo "<li><a href=\"#\" style=\"color:red;\">����</a></li>";
    	}
    	echo '<li><a href="logout.php">�˳�</a></li>';
    }
    ?>
    </li>
  </ul>
</div>