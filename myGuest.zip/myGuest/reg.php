<?php 
 session_start();
 include 'conn.php';
 ?>
 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gbk" />
<title>���԰�</title>
<link rel="stylesheet" type="text/css" href="css/1.css"/>
<link rel="shortcut icon" href="favicon.ico"/>
</head>
<body>
<?php 
include 'validate.php';
include 'header.php';
?>
<div id="main">
  <div id="reg">
    <h1>��Աע�� </h1>
    <form action="reg_do.php" method="post" name="register">
    <dl id="reg_form">
    <?php if(StaticSystem('reg')) {?>
    <dd>�� �� ����<input name="username" type="text" class="text" /></dd>
    <dd>�ܡ����룺<input name="password" type="password" class="text" /></dd>
    <dd>ȷ�����룺<input name="notpassword" type="password" class="text" /></dd>
    <dd>������ʾ��<input name="passt" type="text" class="text" /></dd>
    <dd>����ش�<input name="passd" type="text" class="text" /></dd>
    <dd>�ԡ�����<input name="sex" type="radio" value="��" checked="checked"/>��&nbsp;&nbsp;<input name="sex" type="radio" value="Ů" />Ů</dd>
    <dd class="facedd"><input type="hidden" name="face" value="face/m01.gif" /><img src="face/m01.gif" id="faceImg" onclick="javascript:window.open('face.php','face','width=400,height=400,top=0,left=0,scrollbars=1')"/></dd>
    <dd>�����ʼ���<input name="email" type="text" class="text" /></dd>
    <dd>��Q��Q����<input name="qq" type="text" class="text" /></dd>
    <dd>��ҳ��ַ��<input name="url" type="text" class="text" value="http://" /></dd>
    <?php if(StaticSystem('yzm')) {?>
    <dd>�� ֤ �룺<input name="yzm" type="text" class="yzm" /><img src="code.php" style="position:relative;left:10px;top:10px;cursor:pointer" onclick="javascript:this.src='code.php?tm='+Math.random()" /></dd>
    <?php }
           else{
           	echo 'input type=\"hidden\" name=\"yzm\" value=\"1234\" ';
           }
    ?>
   <dd class="submitted"><input name="send" type="submit" class="submit" value="ע��" onclick="return check();"/></dd>
    <?php 
    } else {
    	echo '<dd style="text-align:center;">�ݲ��ṩע��</dd>';
    }
    ?>
    </dl>
    </form>
  </div>
</div>
<?php 
include 'footer.php';
mysql_close();
?>
</body>
</html>
 