<?php 
     session_start();
     ob_start();
     
     if(!$_POST['send']){
     	echo "<script>alert('�Ƿ���½��');history.back();</script>";
     	exit();
     }
     include 'conn.php';
     if(StaticSystem('yzm')){
     	if($_POST['yzm'] != $_SESSION['code']){
     		echo "<script>alert('��֤�����');history.back();</script>";
     		exit();
     	}
     }
     
     $UserName = $_POST['username']; 
     $PassWord = md5($_POST['password']);

    $sql="select * from g_users where G_UserName='$UserName' and G_PassWord='$PassWord'";
     $query = mysql_query($sql);
     $row = mysql_fetch_array($query);
     if($row){
     	$UserName = $row['G_UserName'];
     	$Face = $row['G_Face'];
     	$Sex = $row['G_Sex'];
     	$QQ = $row['G_QQ'];
     	$Email = $row['G_Email'];
     	$Url = $row['G_Url'];
     	$Login = $_POST['login'];
     	settype($Login,integer);
     	switch ($Login) {
     		case 1:
     		    setcookie('UserName',$UserName);
				setcookie('Sex',$Sex);
				setcookie('Face',$Face);
				setcookie('Email',$Email);
				setcookie('QQ',$QQ);
				setcookie('Url',$Url);
     		    break;
     		case 3600:
				setcookie('UserName',$UserName,time()+3600);
				setcookie('Sex',$Sex,time()+3600);
				setcookie('Face',$Face,time()+3600);
				setcookie('Email',$Email,time()+3600);
				setcookie('QQ',$QQ,time()+3600);
				setcookie('Url',$Url,time()+3600);
				break;
			case 86400:
				setcookie('UserName',$UserName,time()+86400);
				setcookie('Sex',$Sex,time()+86400);
				setcookie('Face',$Face,time()+86400);
				setcookie('Email',$Email,time()+3600);
				setcookie('QQ',$QQ,time()+3600);
				setcookie('Url',$Url,time()+3600);
				break;
			case 604800:
				setcookie('UserName',$UserName,time()+604800);
				setcookie('Sex',$Sex,time()+604800);
				setcookie('Face',$Face,time()+604800);
				setcookie('Email',$Email,time()+3600);
				setcookie('QQ',$QQ,time()+3600);
				setcookie('Url',$Url,time()+3600);
				break;
     		default:
     		break;
     	}
     	
     	if($row['Degree'] == 2){
     		$_SESSION['Admin'] = $UserName;
     	}
     	mysql_close();
     	header('location:index.php');
     
     } 
     else{
     	echo "<script>alert('�û������������');history.back();</script>";
     }
?>