<?php
session_start();
ob_start();
setcookie('user',"");
if(isset($_COOKIE['user'])){
	echo "success";
} else echo "fail";
 ?>