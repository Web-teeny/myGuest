<?php 
     session_start();
     ob_start();
     if(!$_POST['send']){
     	echo "<script>alert(\"�Ƿ�������\");history.back();</script>";
     	exit;
     }
     
     include 'conn.php';
     
     date_default_timezone_set("Asia/ShangHai");
     $Date = date('Y-m-d H:m:s');
     
     if($_COOKIE['ArticleTime']){
     	if(strtotime($Date)-strtotime($_COOKIE['ArticleTime']) < StaticSystem('time')){
     		echo "<script>alert(\"��\".StaticSystem('time').\"��֮���ٷ�����\");history.back();</script>";
     		exit;
     	}
     }
     else{
     	setcookie($_COOKIE['ArticleTime'],date('Y-m-d H:m:s'));
     }
     
     $Title = encode($_POST['title']);
     $UserName = encode($_POST['username']);
     $Sex = $_POST['sex'];
     $Face = $_POST['face'];
     $Email = encode($_POST['email']);
     $QQ = $_POST['qq'];
     $Url = encode($_POST['url']);
     $Brow = $_POST['brow'];
     $Content = encode($_POST['content']);
     
     $sql = "insert into g_article(G_Title,G_UserName,G_Sex,G_Face,G_Email,G_QQ,G_Url,G_Brow,G_Content,G_Date) values ('$Title','$UserName','$Sex','$Face','$Email','$QQ','$Url','$Brow','$Content','$Date')";
     mysql_query($sql);
     if(mysql_affected_rows() == 1){
     	mysql_close();
     	echo '<script>alert(\'���·����ɹ���\');location.href=\'index.php\';</script>';
     }
    
?>