<?php 
session_start();
include 'conn.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gbk" />
<title>��������</title>
<link rel="stylesheet" type="text/css" href="css/1.css"/>
<script type="text/javascript" src="js/post.js"></script>
</head>

<body>
<?php 
     include 'header.php';
     if($_COOKIE['UserName']){
     	$UserNameValue = "readonly=\"readonly\" value=\"{$_COOKIE['UserName']}\"";
     	$FaceValue = $_COOKIE['Face'];
     	$EmailValue = "readonly=\"readonly\" value=\"{$_COOKIE['Email']}\"";
     	$QQValue = "readonly=\"readonly\" value=\"{$_COOKIE['QQ']}\"";
     	$UrlValue = "readonly=\"readonly\" value=\"{$_COOKIE['Url']}\"";	
     }
     else {
     	$UrlValue = "value=\"http://\"";
     	$FaceValue = "face/m01.gif";
     }
     if($_COOKIE['Sex'] == "��"){
     	$Sex1Value = "checked=\"checked\"";
     	$Sex2Value = "disabled=\"disabled\"";
     } else if ($_COOKIE['Sex'] == "Ů"){
     		$Sex2Value = "checked=\"checked\"";
     	    $Sex1Value = "disabled=\"disabled\"";	
     	} else {
     		$Sex1Value = "checked=\"checked\"";
     	}
     
?>
<div id="main">
  <div id="reg">
  <h1>�������� </h1>
    <form action="post_do.php" method="post" name="register">
    <dl id="post">
    <?php 
    if(!StaticSystem('vis') && !$_COOKIE['UserName']){
    	echo '<dd style="text-align:center;">�ο��޷�����</dd>';
    }else {
    ?>
    <dd>�������⣺<input name="title" type="text" class="text" /></dd>
    <dd>�� �� �ˣ�<input name="username" type="text" class="text" <?=$UserNameValue ?>/></dd>
    <dd>�ԡ�����<input name="sex" type="radio" value="��" <?=$Sex1Value ?>/>��&nbsp;&nbsp;<input name="sex" type="radio" value="Ů" <?=$Sex2Value ?>/>Ů</dd>
    <dd class="facedd"><input type="hidden" name="face" value="<?=$FaceValue ?>"  /><img src="<?=$FaceValue ?>" id="faceImg"/></dd>
    <dd>�����ʼ���<input name="email" type="text" class="text" <?=$EmailValue ?>/></dd>
    <dd>��Q��Q����<input name="qq" type="text" class="text" <?=$QQValue ?>/></dd>
    <dd>��ҳ��ַ��<input name="url" type="text" class="text" <?=$UrlValue ?>/></dd>
    <dd style="height:20px;padding-top:10px;">ѡ����飺
    <input type="radio" name="brow" value="images/1/p1.gif" checked="checked" /> <img src="images/1/p1.gif" />
    <input type="radio" name="brow" value="images/1/p1.gif"/> <img src="images/1/p2.gif" />
    <input type="radio" name="brow" value="images/1/p1.gif"/> <img src="images/1/p3.gif" />
    <input type="radio" name="brow" value="images/1/p1.gif"/> <img src="images/1/p4.gif" />
    <input type="radio" name="brow" value="images/1/p1.gif"/> <img src="images/1/p5.gif" />
    <input type="radio" name="brow" value="images/1/p1.gif"/> <img src="images/1/p6.gif" />
    <input type="radio" name="brow" value="images/1/p1.gif"/> <img src="images/1/p7.gif" />
    <input type="radio" name="brow" value="images/1/p1.gif"/> <img src="images/1/p8.gif" />
    </dd>
    <dd style="padding-top:5px;padding-left:66px;height:40px;">
    <input type="radio" name="brow" value="images/1/p1.gif"/> <img src="images/1/p9.gif" />
    <input type="radio" name="brow" value="images/1/p1.gif"/> <img src="images/1/p10.gif" />
    <input type="radio" name="brow" value="images/1/p1.gif"/> <img src="images/1/p11.gif" />
    <input type="radio" name="brow" value="images/1/p1.gif"/> <img src="images/1/p12.gif" />
    <input type="radio" name="brow" value="images/1/p1.gif"/> <img src="images/1/p13.gif" />
    <input type="radio" name="brow" value="images/1/p1.gif"/> <img src="images/1/p14.gif" />
    <input type="radio" name="brow" value="images/1/p1.gif"/> <img src="images/1/p15.gif" />
    <input type="radio" name="brow" value="images/1/p1.gif"/> <img src="images/1/p16.gif" />
    </dd>
    <dd>Q �� ͼ����Qͼϵ�С�1���� Qͼϵ�С�2���� Qͼϵ�С�3��</dd>
    <dd style="text-indent:0;">
    <div id="area"><textarea name="" cols="" rows="9" name="content"></textarea></div>
    <input type="submit" class="submit" value="��������" name="send" onclick="return check();" />
    <input type="button" class="l" value="ע���û�" onclick="javascript:location.href='reg.php'" />
    </dd>
    <?php } ?>
    </dl>
    </form>
  </div>
</div>
<?php 
include 'footer.php';
mysql_close();
?>
</body>
</html>