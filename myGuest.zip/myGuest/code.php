<?php 
 session_start();
 $img_width = 75;
 $img_height = 25;
 
 for($Tmpa = 0;$Tmpa < 4;$Tmpa++){
 	$nmsg.=dechex(rand(0,15));
 }
 
 $_SESSION['code'] = $nmsg;
 
 $aimg = imagecreate($img_width,$img_height);//����ͼƬ
 imagecolorallocate($aimg,255,255,255);
 $black = imagecolorallocate($aimg,0,0,0);
// ImageRectangle($aimg,0,0,$img_height-1,$img_width-1,$black);
//�����������
 for($i = 0; $i < 6; $i++){
 $rcolor=imagecolorallocate($aimg,rand(0,255),rand(0,255),rand(0,255));
 imageline($aimg,rand(0,75),rand(0,75),rand(0,75),rand(0,75),$rcolor);	
 }
 
//����ѩ��
for($i = 0;$i < 100; $i++){
	imagestring($aimg,1,mt_rand(0,$img_width),mt_rand(0,$img_height),'*',
	imagecolorallocate($aimg,mt_rand(200,255),mt_rand(200,255),mt_rand(200,255)));
	
}

//�������
for($i = 0;$i < strlen($_SESSION['code']);$i++){
	imagestring($aimg,mt_rand(3,5),$i*$img_width/4+mt_rand(1,10),mt_rand(1,$img_height/2),$_SESSION['code'][$i],
	imagecolorallocate($aimg,mt_rand(0,100),mt_rand(0,150),mt_rand(0,200)));
	
}
Header("Content-type: image/png");
imagepng($aimg);
imagedestroy($aimg);
 
 ?>